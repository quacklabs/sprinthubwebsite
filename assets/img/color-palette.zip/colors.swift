let primaryColor = UIColor(red: 0.01, green: 0.11, blue: 0.31, alpha: 1.0);
let secondaryColor = UIColor(red: 0.96, green: 0.79, blue: 0.31, alpha: 1.0);
let darkColor = UIColor(red: 0.01, green: 0.01, blue: 0.01, alpha: 1.0);